-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 16 2015 г., 02:11
-- Версия сервера: 5.5.41-0ubuntu0.14.04.1
-- Версия PHP: 5.5.9-1ubuntu4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `autohome_parser`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `id_order` int(11) NOT NULL AUTO_INCREMENT,
  `namber_order` bigint(255) NOT NULL,
  `date_order` int(11) NOT NULL,
  `contacts` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `suma_order` decimal(11,2) NOT NULL,
  `status` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  PRIMARY KEY (`id_order`),
  KEY `namber_order` (`namber_order`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10561 ;

--
-- Дамп данных таблицы `tbl_order`
--

INSERT INTO `tbl_order` (`id_order`, `namber_order`, `date_order`, `contacts`, `suma_order`, `status`) VALUES
(10439, 64593674232349, 1415709660, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64593674232349" class="feedback">Contact</a>', 15.73, '<span class="f-left"> 							Завершено  </span>'),
(10440, 64593674222349, 1415709660, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64593674222349" class="feedback">Contact</a>', 8.94, '<span class="f-left"> 							Завершено  </span>'),
(10441, 64583269672349, 1415709120, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64583269672349" class="feedback">Contact</a>', 18.29, '<span class="f-left"> 							Завершено  </span>'),
(10442, 64583269662349, 1415709120, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64583269662349" class="feedback">Contact</a>', 10.38, '<span class="f-left"> 							Завершено  </span>'),
(10443, 64572646192349, 1415706060, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64572646192349" class="feedback">Contact</a>', 2.95, '<span class="f-left"> 							Завершено  </span>'),
(10444, 64572646182349, 1415706060, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64572646182349" class="feedback">Contact</a>', 13.74, '<span class="f-left"> 							Завершено  </span>'),
(10445, 64572646152349, 1415706060, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64572646152349" class="feedback">Contact</a>', 19.58, '<span class="f-left"> 							Завершено  </span>'),
(10446, 64572646142349, 1415706060, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64572646142349" class="feedback">Contact</a>', 2.56, '<span class="f-left"> 							Завершено  </span>'),
(10447, 64571488532349, 1415705580, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64571488532349" class="feedback">Contact</a>', 17.58, '<span class="f-left"> 							Завершено  </span>'),
(10448, 64489549792349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549792349" class="feedback">Contact</a>', 20.19, '<span class="f-left"> 							Завершено  </span>'),
(10449, 64489549742349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549742349" class="feedback">Contact</a>', 11.46, '<span class="f-left"> 							Завершено  </span>'),
(10450, 64489549752349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549752349" class="feedback">Contact</a>', 7.76, '<span class="f-left"> 							Завершено  </span>'),
(10451, 64489549762349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549762349" class="feedback">Contact</a>', 8.74, '<span class="f-left"> 							Завершено  </span>'),
(10452, 64489549772349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549772349" class="feedback">Contact</a>', 2.61, '<span class="f-left"> 							Завершено  </span>'),
(10453, 64489549782349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549782349" class="feedback">Contact</a>', 3.88, '<span class="f-left"> 							Завершено  </span>'),
(10454, 64489549712349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549712349" class="feedback">Contact</a>', 15.58, '<span class="f-left"> 							Завершено  </span>'),
(10455, 64489549722349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549722349" class="feedback">Contact</a>', 12.14, '<span class="f-left"> 							Завершено  </span>'),
(10456, 64489549732349, 1415662860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64489549732349" class="feedback">Contact</a>', 8.44, '<span class="f-left"> 							Завершено  </span>'),
(10457, 64140425121401, 1413257880, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64140425121401" class="feedback">Contact</a>', 38.40, '<span class="f-left"> 							Завершено  </span>'),
(10458, 64128376011401, 1413197040, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64128376011401" class="feedback">Contact</a>', 38.40, '<span class="f-left"> 							Завершено  </span>'),
(10459, 64088134991401, 1412916420, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64088134991401" class="feedback">Contact</a>', 20.06, '<span class="f-left"> 							Завершено  </span>'),
(10460, 64091038801401, 1412908320, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64091038801401" class="feedback">Contact</a>', 15.60, '<span class="f-left"> 							Завершено  </span>'),
(10461, 64067288941401, 1412823300, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64067288941401" class="feedback">Contact</a>', 16.00, '<span class="f-left"> 							Завершено  </span>'),
(10462, 64067288951401, 1412823300, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64067288951401" class="feedback">Contact</a>', 36.00, '<span class="f-left"> 							Завершено  </span>'),
(10463, 64050923221401, 1412719560, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64050923221401" class="feedback">Contact</a>', 17.00, '<span class="f-left"> 							Завершено  </span>'),
(10464, 63893693661401, 1411517940, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=63893693661401" class="feedback">Contact</a>', 44.80, '<span class="f-left"> 							Завершено  </span>'),
(10465, 63882615201401, 1411446240, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=63882615201401" class="feedback">Contact</a>', 20.10, '<span class="f-left"> 							Завершено  </span>'),
(10466, 61102788581401, 1392355980, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=61102788581401" class="feedback">Contact</a>', 25.19, '<span class="f-left"> 							Завершено  </span>'),
(10467, 64199119881401, 1413628380, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64199119881401" class="feedback">Contact</a>', 15.63, '<span class="f-left"> 							Завершено  </span>'),
(10468, 64187122911401, 1413625380, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64187122911401" class="feedback">Contact</a>', 12.00, '<span class="f-left"> 							Завершено  </span>'),
(10469, 64183602681401, 1413603420, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64183602681401" class="feedback">Contact</a>', 11.04, '<span class="f-left"> 							Закрыт  </span>'),
(10470, 64183602691401, 1413603420, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64183602691401" class="feedback">Contact</a>', 12.70, '<span class="f-left"> 							Закрыт  </span>'),
(10471, 64194317631401, 1413595740, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64194317631401" class="feedback">Contact</a>', 12.10, '<span class="f-left"> 							Завершено  </span>'),
(10472, 64172407221401, 1413521760, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64172407221401" class="feedback">Contact</a>', 20.20, '<span class="f-left"> 							Завершено  </span>'),
(10473, 64177078091401, 1413455040, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64177078091401" class="feedback">Contact</a>', 20.40, '<span class="f-left"> 							Завершено  </span>'),
(10474, 64148459341401, 1413341400, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64148459341401" class="feedback">Contact</a>', 61.30, '<span class="f-left"> 							Завершено  </span>'),
(10475, 64147172141401, 1413330300, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64147172141401" class="feedback">Contact</a>', 13.85, '<span class="f-left"> 							Закрыт  </span>'),
(10476, 64143834791401, 1413259680, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64143834791401" class="feedback">Contact</a>', 67.60, '<span class="f-left"> 							Завершено  </span>'),
(10477, 64327745911401, 1414494780, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64327745911401" class="feedback">Contact</a>', 14.93, '<span class="f-left"> 							Завершено  </span>'),
(10478, 64323063971401, 1414477620, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64323063971401" class="feedback">Contact</a>', 18.75, '<span class="f-left"> 							Завершено  </span>'),
(10479, 64316553831401, 1414408680, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64316553831401" class="feedback">Contact</a>', 139.20, '<span class="f-left"> 							Завершено  </span>'),
(10480, 64291673681401, 1414223520, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64291673681401" class="feedback">Contact</a>', 28.75, '<span class="f-left"> 							Завершено  </span>'),
(10481, 64275921191401, 1414219620, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64275921191401" class="feedback">Contact</a>', 7.68, '<span class="f-left"> 							Завершено  </span>'),
(10482, 64259058161401, 1414053660, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64259058161401" class="feedback">Contact</a>', 43.00, '<span class="f-left"> 							Завершено  </span>'),
(10483, 64207320051401, 1413778680, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64207320051401" class="feedback">Contact</a>', 12.87, '<span class="f-left"> 							Завершено  </span>'),
(10484, 64217303401401, 1413778440, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64217303401401" class="feedback">Contact</a>', 14.38, '<span class="f-left"> 							Завершено  </span>'),
(10485, 64205488441401, 1413772560, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64205488441401" class="feedback">Contact</a>', 5.67, '<span class="f-left"> 							Завершено  </span>'),
(10486, 64205488451401, 1413772560, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64205488451401" class="feedback">Contact</a>', 1.19, '<span class="f-left"> 							Завершено  </span>'),
(10487, 64478213521401, 1415657940, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64478213521401" class="feedback">Contact</a>', 194.78, '<span class="f-left"> 							Завершено  </span>'),
(10488, 64451298851401, 1415440140, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64451298851401" class="feedback">Contact</a>', 6.50, '<span class="f-left"> 							Завершено  </span>'),
(10489, 64451180191401, 1415426460, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64451180191401" class="feedback">Contact</a>', 7.00, '<span class="f-left"> 							Завершено  </span>'),
(10490, 64351693791401, 1414667580, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64351693791401" class="feedback">Contact</a>', 8.94, '<span class="f-left"> 							Завершено  </span>'),
(10491, 64356158241401, 1414665720, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64356158241401" class="feedback">Contact</a>', 28.28, '<span class="f-left"> 							Завершено  </span>'),
(10492, 64341948481401, 1414584660, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64341948481401" class="feedback">Contact</a>', 11.54, '<span class="f-left"> 							Завершено  </span>'),
(10493, 64342421201401, 1414584120, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64342421201401" class="feedback">Contact</a>', 3.20, '<span class="f-left"> 							Завершено  </span>'),
(10494, 64329166131401, 1414583280, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64329166131401" class="feedback">Contact</a>', 8.50, '<span class="f-left"> 							Завершено  </span>'),
(10495, 64341506481401, 1414583220, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64341506481401" class="feedback">Contact</a>', 6.25, '<span class="f-left"> 							Завершено  </span>'),
(10496, 64329960271401, 1414581540, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64329960271401" class="feedback">Contact</a>', 14.20, '<span class="f-left"> 							Завершено  </span>'),
(10497, 65045083971401, 1418290200, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65045083971401" class="feedback">Contact</a>', 24.70, '<span class="f-left"> 							Завершено  </span>'),
(10498, 64743250891401, 1416436800, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64743250891401" class="feedback">Contact</a>', 161.50, '<span class="f-left"> 							Завершено  </span>'),
(10499, 64619010471401, 1415742360, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64619010471401" class="feedback">Contact</a>', 1.96, '<span class="f-left"> 							Завершено  </span>'),
(10500, 64580500251401, 1415706540, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64580500251401" class="feedback">Contact</a>', 8.62, '<span class="f-left"> 							Завершено  </span>'),
(10501, 64580500231401, 1415706540, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64580500231401" class="feedback">Contact</a>', 15.46, '<span class="f-left"> 							Завершено  </span>'),
(10502, 64580500241401, 1415706540, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64580500241401" class="feedback">Contact</a>', 25.89, '<span class="f-left"> 							Завершено  </span>'),
(10503, 64512847731401, 1415679420, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64512847731401" class="feedback">Contact</a>', 14.37, '<span class="f-left"> 							Завершено  </span>'),
(10504, 64512847741401, 1415679420, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64512847741401" class="feedback">Contact</a>', 11.12, '<span class="f-left"> 							Завершено  </span>'),
(10505, 64486022411401, 1415661060, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64486022411401" class="feedback">Contact</a>', 57.15, '<span class="f-left"> 							Завершено  </span>'),
(10506, 64484053791401, 1415659620, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=64484053791401" class="feedback">Contact</a>', 123.28, '<span class="f-left"> 							Закрыт  </span>'),
(10507, 65400248891401, 1421102700, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65400248891401" class="feedback">Contact</a>', 22.90, '<span class="f-left"> 							Завершено  </span>'),
(10508, 65406617441401, 1421101560, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65406617441401" class="feedback">Contact</a>', 27.00, '<span class="f-left"> 							Завершено  </span>'),
(10509, 65411757351401, 1421040540, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65411757351401" class="feedback">Contact</a>', 36.58, '<span class="f-left"> 							Завершено  </span>'),
(10510, 65411990741401, 1421036940, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65411990741401" class="feedback">Contact</a>', 30.24, '<span class="f-left"> 							Завершено  </span>'),
(10511, 65150959161401, 1419032880, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65150959161401" class="feedback">Contact</a>', 4.40, '<span class="f-left"> 							Завершено  </span>'),
(10512, 65132629461401, 1418968740, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65132629461401" class="feedback">Contact</a>', 53.50, '<span class="f-left"> 							Завершено  </span>'),
(10513, 65144670031401, 1418963880, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65144670031401" class="feedback">Contact</a>', 26.75, '<span class="f-left"> 							Завершено  </span>'),
(10514, 65062611171401, 1418292360, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65062611171401" class="feedback">Contact</a>', 42.24, '<span class="f-left"> 							Завершено  </span>'),
(10515, 65051304141401, 1418291820, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65051304141401" class="feedback">Contact</a>', 25.53, '<span class="f-left"> 							Завершено  </span>'),
(10516, 65045561981401, 1418291700, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65045561981401" class="feedback">Contact</a>', 23.76, '<span class="f-left"> 							Завершено  </span>'),
(10517, 65510239691401, 1421663400, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65510239691401" class="feedback">Contact</a>', 43.30, '<span class="f-left"> 							Завершено  </span>'),
(10518, 65441490071401, 1421301900, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65441490071401" class="feedback">Contact</a>', 15.46, '<span class="f-left"> 							Завершено  </span>'),
(10519, 65434804431401, 1421300820, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65434804431401" class="feedback">Contact</a>', 11.90, '<span class="f-left"> 							Завершено  </span>'),
(10520, 65440490391401, 1421298240, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65440490391401" class="feedback">Contact</a>', 17.80, '<span class="f-left"> 							Завершено  </span>'),
(10521, 65451592541401, 1421293260, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65451592541401" class="feedback">Contact</a>', 25.10, '<span class="f-left"> 							Завершено  </span>'),
(10522, 65437296331401, 1421281560, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65437296331401" class="feedback">Contact</a>', 17.98, '<span class="f-left"> 							Завершено  </span>'),
(10523, 65436219001401, 1421280300, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65436219001401" class="feedback">Contact</a>', 4.30, '<span class="f-left"> 							Завершено  </span>'),
(10524, 65420381831401, 1421218680, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65420381831401" class="feedback">Contact</a>', 16.30, '<span class="f-left"> 							Завершено  </span>'),
(10525, 65420712981401, 1421108160, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65420712981401" class="feedback">Contact</a>', 14.20, '<span class="f-left"> 							Завершено  </span>'),
(10526, 65400566171401, 1421103120, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65400566171401" class="feedback">Contact</a>', 9.50, '<span class="f-left"> 							Завершено  </span>'),
(10527, 65692842281401, 1422943500, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65692842281401" class="feedback">Contact</a>', 30.90, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10528, 65695734071401, 1422939060, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65695734071401" class="feedback">Contact</a>', 11.50, '<span class="f-left"> 							Завершено  </span>'),
(10529, 65669189171401, 1422854340, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65669189171401" class="feedback">Contact</a>', 24.26, '<span class="f-left"> 							Завершено  </span>'),
(10530, 65677525901401, 1422853200, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65677525901401" class="feedback">Contact</a>', 30.32, '<span class="f-left"> 							Завершено  </span>'),
(10531, 65491763691401, 1421669580, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65491763691401" class="feedback">Contact</a>', 61.04, '<span class="f-left"> 							Завершено  </span>'),
(10532, 65497093401401, 1421669100, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65497093401401" class="feedback">Contact</a>', 9.60, '<span class="f-left"> 							Завершено  </span>'),
(10533, 65511318621401, 1421668680, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65511318621401" class="feedback">Contact</a>', 9.92, '<span class="f-left"> 							Завершено  </span>'),
(10534, 65496852681401, 1421667720, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65496852681401" class="feedback">Contact</a>', 17.70, '<span class="f-left"> 							Завершено  </span>'),
(10535, 65496179431401, 1421666520, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65496179431401" class="feedback">Contact</a>', 49.18, '<span class="f-left"> 							Завершено  </span>'),
(10536, 65496415531401, 1421666100, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65496415531401" class="feedback">Contact</a>', 23.92, '<span class="f-left"> 							Завершено  </span>'),
(10537, 65803751391401, 1423546620, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65803751391401" class="feedback">Contact</a>', 28.56, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10538, 65779261071401, 1423544520, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65779261071401" class="feedback">Contact</a>', 15.63, '<span class="f-left"> 							Завершено  </span>'),
(10539, 65801319001401, 1423540860, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65801319001401" class="feedback">Contact</a>', 60.08, '<span class="f-left"> 							Завершено  </span>'),
(10540, 65709635511401, 1422948300, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65709635511401" class="feedback">Contact</a>', 14.46, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10541, 65697776901401, 1422948180, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65697776901401" class="feedback">Contact</a>', 17.25, '<span class="f-left"> 							Завершено  </span>'),
(10542, 65685104001401, 1422948120, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65685104001401" class="feedback">Contact</a>', 15.40, '<span class="f-left"> 							Завершено  </span>'),
(10543, 65697375811401, 1422946500, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65697375811401" class="feedback">Contact</a>', 3.60, '<span class="f-left"> 							Завершено  </span>'),
(10544, 65693281571401, 1422945960, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65693281571401" class="feedback">Contact</a>', 7.44, '<span class="f-left"> 							Завершено  </span>'),
(10545, 65684703531401, 1422945720, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65684703531401" class="feedback">Contact</a>', 30.69, '<span class="f-left"> 							Завершено  </span>'),
(10546, 65696578741401, 1422945000, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65696578741401" class="feedback">Contact</a>', 12.92, '<span class="f-left"> 							Завершено  </span>'),
(10547, 65831242981401, 1423792380, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65831242981401" class="feedback">Contact</a>', 14.80, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10548, 65845597931401, 1423792320, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65845597931401" class="feedback">Contact</a>', 5.70, '<span class="f-left"> 							Завершено  </span>'),
(10549, 65831163181401, 1423792200, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65831163181401" class="feedback">Contact</a>', 3.42, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10550, 65845358451401, 1423792080, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65845358451401" class="feedback">Contact</a>', 4.65, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10551, 65821423311401, 1423792020, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65821423311401" class="feedback">Contact</a>', 9.40, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10552, 65821185901401, 1423791900, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65821185901401" class="feedback">Contact</a>', 0.69, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10553, 65844596821401, 1423786380, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65844596821401" class="feedback">Contact</a>', 2.36, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10554, 65838312661401, 1423738260, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65838312661401" class="feedback">Contact</a>', 112.13, '<span class="f-left"> 							Завершено  </span>'),
(10555, 65812943131401, 1423737780, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65812943131401" class="feedback">Contact</a>', 185.74, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10556, 65788889511401, 1423546740, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=65788889511401" class="feedback">Contact</a>', 28.60, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10557, 66224024961401, 1426052040, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=66224024961401" class="feedback">Contact</a>', 14.12, '<span class="f-left"> 							Ожидается отправка  </span>'),
(10558, 66236808721401, 1426049760, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=66236808721401" class="feedback">Contact</a>', 26.99, '<span class="f-left"> 							Ожидается отправка  </span>'),
(10559, 66220946121401, 1426036500, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=66220946121401" class="feedback">Contact</a>', 24.87, '<span class="f-left"> 							Ожидается подтверждение  </span>'),
(10560, 66254713841401, 1426034520, '<a href="http://trade.aliexpress.com/order_detail.htm?orderId=66254713841401" class="feedback">Contact</a>', 24.80, '<span class="f-left"> 							Ожидается подтверждение  </span>');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
