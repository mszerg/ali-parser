<?php // login.php
$db_hostname = 'localhost';
$db_database = 'autohome_parser';
$db_username = 'autohome_root';
$db_password = 'basurman';
?>